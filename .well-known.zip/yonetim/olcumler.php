<?php
$admin_giris_zorunlu = 1;
?>
<?php
require_once __DIR__ . '/../src/autoload.php';
?>

<?php
if (isset($_POST['olcum_ekle'])) {
    $query = $conn->prepare("INSERT INTO olcum SET kullanici_id = ?, boy = ?, kilo = ?, bel_olcusu = ?, omuz_olcusu = ?, kalca = ?, sag_bacak = ?, sol_bacak = ?, sag_kol = ?, sol_kol = ?, gogus = ?, boyun = ?, yag_orani = ?, vucut_kitle_indeksi = ?");
    $insert = $query->execute(array($_GET['id'], $_POST['boy'], $_POST['kilo'], $_POST['bel_olcusu'], $_POST['omuz_olcusu'], $_POST['kalca'], $_POST['sag_bacak'], $_POST['sol_bacak'], $_POST['sag_kol'], $_POST['sol_kol'], $_POST['gogus'], $_POST['boyun'], $_POST['yag_orani'], $_POST['vucut_kitle_indeksi']));
    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit;
}

if (isset($_POST['sil'])) {
    $stmt = $conn->prepare("DELETE FROM olcum WHERE id = ?");
    $stmt->execute([$_POST['sil']]);
}

?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors" />
    <meta name="generator" content="Hugo 0.104.2" />
    <!--Sidebar Başlangıç-->
    <title>Yönetici-Müşteriler</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/sidebars/" />
    <link href="../css/font-face.css" rel="stylesheet" media="all" />
    <link href="../vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all" />
    <link href="../vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all" />
    <link href="../vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all" />

    <link href="../bootstrap.min.css" rel="stylesheet" />

    <style>
        .main-content {
            overflow: scroll;
        }

        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }

        .b-example-divider {
            height: 3rem;
            background-color: rgba(0, 0, 0, 0.1);
            border: solid rgba(0, 0, 0, 0.15);
            border-width: 1px 0;
            box-shadow: inset 0 0.5em 1.5em rgba(0, 0, 0, 0.1),
                inset 0 0.125em 0.5em rgba(0, 0, 0, 0.15);
        }

        .b-example-vr {
            flex-shrink: 0;
            width: 1.5rem;
            height: 100vh;
        }

        .bi {
            vertical-align: -0.125em;
            fill: currentColor;
        }

        .nav-scroller {
            position: relative;
            z-index: 2;
            height: 2.75rem;
            overflow-y: hidden;
        }

        .nav-scroller .nav {
            display: flex;
            flex-wrap: nowrap;
            padding-bottom: 1rem;
            margin-top: -1px;
            overflow-x: auto;
            text-align: center;
            white-space: nowrap;
            -webkit-overflow-scrolling: touch;
        }
    </style>

    <!-- Custom styles for this template -->
    <link href="../sidebars.css" rel="stylesheet" />




</head>

<body>


    <main class="d-flex flex-nowrap">
        <?php include './navbar.php'; ?>
        <div class="b-example-divider b-example-vr"></div>

        <div class="main-content w-100">
            <div class="section__content section__content--p30">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <h5 class="card-header">Müşteri Ekle</h5>
                                <div class="card-body">
                                    <form action="" method="post">
                                        <input type="text" class="form-control" name="boy" placeholder="boy">
                                        <input type="text" class="form-control" name="kilo" placeholder="kilo">
                                        <input type="text" class="form-control" name="bel_olcusu"
                                            placeholder="bel olcusu"><input type="text" class="form-control"
                                            name="omuz_olcusu" placeholder="omuz olcusu">
                                        <input type="text" class="form-control" name="kalca" placeholder="kalca">
                                        <input type="text" class="form-control" name="sag_bacak"
                                            placeholder="sag bacak">
                                        <input type="text" class="form-control" name="sol_bacak"
                                            placeholder="sol bacak">
                                        <input type="text" class="form-control" name="sag_kol" placeholder="sag kol">
                                        <input type="text" class="form-control" name="sol_kol" placeholder="sol kol">
                                        <input type="text" class="form-control" name="gogus" placeholder="gogus">
                                        <input type="text" class="form-control" name="boyun" placeholder="boyun"> <input
                                            type="text" class="form-control" name="yag_orani" placeholder="yag orani">
                                        <input type="text" class="form-control" name="vucut_kitle_indeksi"
                                            placeholder="vucut kitle indeksi">
                                        <button class="btn btn-secondary mt-2" name="olcum_ekle" value="1">Ekle</button>
                                    </form>
                                </div>
                            </div>
                            <table class="table">
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="col">Boy</th>
                                        <th scope="col">Kilo</th>
                                        <th scope="col">Bel Ölçüsü</th>
                                        <th scope="col">Omuz Ölçüsü</th>
                                        <th scope="col">Kalça</th>
                                        <th scope="col">Sağ Bacak</th>
                                        <th scope="col">Sol Bacak</th>
                                        <th scope="col">Sağ Kol</th>
                                        <th scope="col">Sol Kol</th>
                                        <th scope="col">Göğüs</th>
                                        <th scope="col">Boyun</th>
                                        <th scope="col">Yağ Oranı</th>
                                        <th scope="col">Vücut Kitle İndeksi</th>
                                        <th>işlem</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $olcum_cek = $conn->prepare("SELECT * FROM olcum WHERE kullanici_id = ? ORDER BY id DESC");
                                    $olcum_cek->execute([$_GET['id']]);
                                    while ($olcum = $olcum_cek->fetch(PDO::FETCH_ASSOC)) { ?>
                                        <tr>
                                            <td>
                                                <?= $olcum['boy']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['kilo']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['bel_olcusu']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['omuz_olcusu']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['kalca']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['sag_bacak']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['sol_bacak']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['sag_kol']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['sol_kol']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['gogus']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['boyun']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['yag_orani']; ?>
                                            </td>
                                            <td>
                                                <?= $olcum['vucut_kitle_indeksi']; ?>
                                            </td>
                                            <td>
                                                <form action="" method="post">
                                                    <button class="btn btn-danger" name="sil"
                                                        value="<?= $olcum['id']; ?>">Sil</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>



        <!--data table bitis-->
    </main>
    <link href="../mustericss.css" rel="stylesheet" media="all" />
    <link href="../css/theme.css" rel="stylesheet" media="all" />

    <link href="../css/font-face.css" rel="stylesheet" media="all">
    <!-- Jquery JS-->
    <script src="../vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="../vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="../vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="../vendor/slick/slick.min.js"></script>
    <script src="../vendor/wow/wow.min.js"></script>
    <script src="../vendor/animsition/animsition.min.js"></script>
    <script src="../vendor/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <script src="../vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="../vendor/counter-up/jquery.counterup.min.js"></script>
    <script src="../vendor/circle-progress/circle-progress.min.js"></script>
    <script src="../vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="../vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="../vendor/select2/select2.min.js"></script>

    <!-- Main JS-->
    <script src="../main.js"></script>
    <link href="../css/theme.css" rel="stylesheet" media="all">
    <link href="../css/font-face.css" rel="stylesheet" media="all">

    <!--İstatistik Bitiş-->

    </main>


    <!-- Vendor JS       -->

    <script src="../vendor/vector-map/jquery.vmap.js"></script>
    <script src="../vendor/vector-map/jquery.vmap.min.js"></script>
    <script src="../vendor/vector-map/jquery.vmap.sampledata.js"></script>
    <script src="../vendor/vector-map/jquery.vmap.world.js"></script>

    <!-- Fontfaces CSS-->
    <link href="../css/font-face.css" rel="stylesheet" media="all">
    <link href="../vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="../vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="../vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="../vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="../vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="../vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="../vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="../vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="../vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="../vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="../vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <link href="../vendor/vector-map/jqvmap.min.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="../css/theme.css" rel="stylesheet" media="all">

    <!-- Main JS-->
    <script src="main.js"></script>

    <script src="https://kit.fontawesome.com/ab7283eac0.js" crossorigin="anonymous"></script>
    <script src="../bootstrap.bundle.min.js"></script>
    <script src="../vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="../vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <script src="../sidebars.js"></script>





</body>

</html>
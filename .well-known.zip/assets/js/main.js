const countDownDate = new Date("08-15-2023").getTime();

let dateCounter = setInterval(() => {
    let now = new Date().getTime();
    let distance = countDownDate - now;

    let days = Math.floor(distance / (1000 * 60 * 60 * 24));
    let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    let seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    days = days.toString();
    hours = hours.toString();
    minutes = minutes.toString();
    seconds = seconds.toString();

    $('#timer').html(days);

    if (distance < 0) {
        clearInterval(dateCounter);
    }
}, 1000);
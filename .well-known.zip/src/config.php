<?php
session_start();
$servername = "localhost";
$username = "hazaryilmaz_hazar";
$password = "H.y32566941152";
$database_name = "hazaryilmaz_sporsalonu";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$database_name;charset=utf8", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}







<?php
if (isset($_SESSION['giris_bilgileri'])) {
    $kullanicikontrol = $conn->prepare("SELECT * FROM musteri_kayit WHERE id=?");
    $kullanicikontrol->execute([$_SESSION['giris_bilgileri']['id']]);
    $kullanicikontrolsayisi = $kullanicikontrol->rowCount();
    if ($kullanicikontrolsayisi > 0) {
        $_SESSION['giris_bilgileri'] = $kullanicikontrol->fetch(PDO::FETCH_ASSOC);
    }
}
//
if (isset($_POST["txttc"]) && isset($_POST["txtsifre"])) {
    $kullanicikontrol = $conn->prepare("SELECT * FROM musteri_kayit WHERE tc=?");
    $kullanicikontrol->execute([$_POST["txttc"]]);
    $kullanicikontrolsayisi = $kullanicikontrol->rowCount();

    if ($kullanicikontrolsayisi > 0) {
        $kullanici = $kullanicikontrol->fetch(PDO::FETCH_ASSOC);
        $storedHash = $kullanici['sifre'];
        $enteredPassword = $_POST["txtsifre"];

        if (password_verify($enteredPassword, $storedHash)) {
            $_SESSION['giris_bilgileri'] = $kullanici;
        } else {
            unset($_SESSION['giris_bilgileri']);
        }
    } else {
        unset($_SESSION['giris_bilgileri']);
    }
}
//
  


if (isset($giris_zorunlu)) {
    if ($giris_zorunlu == 0) {
        if (isset($_SESSION['giris_bilgileri'])) {


            echo "<script>
            if (confirm('Giriş Başarılı')) {
                window.location.href = 'index1.php';
            }
            else
            {
                window.location.href = '';
            }

        </script>";
            
        }
    } else if ($giris_zorunlu == 1) {
        if (!isset($_SESSION['giris_bilgileri'])) {
            echo "<script>
                    if (confirm('Kullanıcı Adı veya şifreniz yanlış. Tamam\'a basarak tekrar giriş yapabilirsiniz.')) {
                        window.location.href = 'giris.php';
                    }
                    else
                    {
                        window.location.href = '';
                    }

                </script>";
           
        }
    }
}

if (isset($admin_giris_zorunlu)) {
    if ($admin_giris_zorunlu == 0) {
        if (isset($_SESSION['admin_giris_bilgileri'])) {
            echo "<script>
            if (confirm('Giriş Başarılı')) {
                window.location.href = 'index1.php';
            }
            else
            {
                window.location.href = '';
            }

        </script>";
           
        }
    } else if ($admin_giris_zorunlu == 1) {
        if (!isset($_SESSION['admin_giris_bilgileri'])) {
            echo "<script>
            if (confirm('Kullanıcı Adı veya şifreniz yanlış. Tamam\'a basarak tekrar giriş yapabilirsiniz.')) {
                window.location.href = 'giris.php';
            }
            else
            {
                window.location.href = '';
            }

        </script>";
            
        }
    }
}

?>
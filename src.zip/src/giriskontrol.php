<?php
if (isset($_SESSION['giris_bilgileri'])) {
    $kullanicikontrol = $conn->prepare("SELECT * FROM musteri_kayit WHERE id=?");
    $kullanicikontrol->execute([$_SESSION['giris_bilgileri']['id']]);
    $kullanicikontrolsayisi = $kullanicikontrol->rowCount();
    if ($kullanicikontrolsayisi > 0) {
        $_SESSION['giris_bilgileri'] = $kullanicikontrol->fetch(PDO::FETCH_ASSOC);
    }
}
if (isset($_POST["txttc"]) && isset($_POST["txtsifre"])) {
    $kullanicikontrol = $conn->prepare("SELECT * FROM musteri_kayit WHERE tc=? and sifre=?");
    $kullanicikontrol->execute([$_POST["txttc"], $_POST["txtsifre"]]);
    $kullanicikontrolsayisi = $kullanicikontrol->rowCount();
    if ($kullanicikontrolsayisi > 0) {
        $_SESSION['giris_bilgileri'] = $kullanicikontrol->fetch(PDO::FETCH_ASSOC);
    } else {
        unset($_SESSION['giris_bilgileri']);
    }

    $adminkontrol = $conn->prepare("SELECT * FROM admin_kayit WHERE tc=? and sifre=?");
    $adminkontrol->execute([$_POST["txttc"], $_POST["txtsifre"]]);
    $adminkontrolsayisi = $adminkontrol->rowCount();
    if ($adminkontrolsayisi > 0) {
        $_SESSION['admin_giris_bilgileri'] = $adminkontrol->fetch(PDO::FETCH_ASSOC);
    } else {
        unset($_SESSION['admin_giris_bilgileri']);
    }
}

if (isset($giris_zorunlu)) {
    if ($giris_zorunlu == 0) {
        if (isset($_SESSION['giris_bilgileri'])) {
            header("Location: ./index.php");
            exit;
        }
    } else if ($giris_zorunlu == 1) {
        if (!isset($_SESSION['giris_bilgileri'])) {
            header("Location: ./giris.php");
            exit;
        }
    }
}

if (isset($admin_giris_zorunlu)) {
    if ($admin_giris_zorunlu == 0) {
        if (isset($_SESSION['admin_giris_bilgileri'])) {
            header("Location: ./index.php");
            exit;
        }
    } else if ($admin_giris_zorunlu == 1) {
        if (!isset($_SESSION['admin_giris_bilgileri'])) {
            header("Location: ./giris.php");
            exit;
        }
    }
}